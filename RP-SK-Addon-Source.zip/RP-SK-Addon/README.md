# RP SK Addon (Paper 1.21.4)

Bu eklenti mevcut `RpSunucusu-1.0.jar` eklentisine ek olarak çalışır; mevcut JAR'ın yerine geçmez.

## Özellikler
- Meslek seçim menüsünde boş olan 31. slota Yetenekler girişini ekler.
- Her mesleğin kendi SK puanı ve 5 kademeli yetenek ağacı vardır.
- Her 25 meslek XP için 1 SK verir.
- `/sk` yetenek menüsünü açar.
- OP: `/skver <oyuncu> <miktar>`
- SK ve yetenek seviyeleri `plugins/RPSKAddon/skills.yml` içinde saklanır.
- Rank eşikleri 0 / 500 / 1500 / 3500 / 8000 olarak yükseltilir.

## Derleme
`libs/RpSunucusu-1.0.jar` dosyası Maven system dependency olarak kullanılır. GitHub'a bu klasörü repo olarak yükle; Actions sekmesinden **Build RP SK Addon** workflow'unu çalıştır. Oluşan artifact içinden `rp-sk-addon-1.0.0.jar` dosyasını indir.

## Kurulum
1. Eski `RpSunucusu-1.0.jar` dosyanı yedekle ve sunucuyu kapat.
2. Eski RP eklentini yerinde bırak.
3. `rp-sk-addon-1.0.0.jar` dosyasını `plugins` klasörüne koy.
4. Sunucuyu aç. Paper 1.21.4 / Java 21 gerektirir.

Not: Yetenek etkileri ilk sürümde Madenci (Haste), Polis (Resistance), Mafya (Strength), Doktor (Regeneration) için açılır. Diğer meslekler için puan/level altyapısı hazırdır; özel oyun etkileri ayrıca tanımlanabilir.
