package com.rp.sk;

import com.rp.Job;
import com.rp.PlayerData;
import com.rp.RpPlugin;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.*;

public final class RPSKAddon extends JavaPlugin implements Listener, CommandExecutor {
 private RpPlugin rp; private File dataFile; private YamlConfiguration data;
 private final Map<UUID,Integer> lastXp=new HashMap<>();
 private static final String TITLE="§8✦ §6MESLEK YETENEKLERİ";
 @Override public void onEnable(){
  if(!(Bukkit.getPluginManager().getPlugin("RpSunucusu") instanceof RpPlugin p)){getLogger().severe("RpSunucusu bulunamadi!");Bukkit.getPluginManager().disablePlugin(this);return;} rp=p;
  dataFile=new File(getDataFolder(),"skills.yml"); if(!getDataFolder().exists())getDataFolder().mkdirs(); data=YamlConfiguration.loadConfiguration(dataFile);
  Bukkit.getPluginManager().registerEvents(this,this); getCommand("sk").setExecutor(this); getCommand("skver").setExecutor(this);
  // Rütbe eşiklerini zorlaştır: mevcut XP değerleri korunur, yalnızca yeni eşikler uygulanır.
  int[] t=Job.THRESH; int[] harder={0,500,1500,3500,8000}; System.arraycopy(harder,0,t,0,Math.min(t.length,harder.length));
  Bukkit.getScheduler().runTaskTimer(this,this::trackXp,100L,100L);
  Bukkit.getScheduler().runTaskTimer(this,this::applyPassives,40L,40L);
 }
 @Override public void onDisable(){save();}
 private void save(){try{data.save(dataFile);}catch(Exception e){getLogger().severe("SK kaydedilemedi: "+e.getMessage());}}
 private String base(Player p){return p.getUniqueId().toString();}
 private int points(Player p){return data.getInt(base(p)+".points",0);}
 private int level(Player p,String skill){return data.getInt(base(p)+".skills."+skill,0);}
 private void setPoints(Player p,int n){data.set(base(p)+".points",Math.max(0,n));save();}
 private void addPoints(Player p,int n){setPoints(p,points(p)+n);}
 private Job job(Player p){PlayerData d=rp.get(p);return d==null?null:Job.from(d.job);}
 private void trackXp(){for(Player p:Bukkit.getOnlinePlayers()){PlayerData d=rp.get(p);if(d==null||!d.loggedIn)continue;Job j=job(p);if(j==null)continue;int now=d.xpOf(j);String k=base(p)+"."+j.name();int old=data.getInt("seen."+k,now);if(now>old){int gained=(now-old)/25; if(gained>0){addPoints(p,gained);p.sendMessage("§6[SK] §e"+gained+" yetenek puani kazandin!");} }data.set("seen."+k,now);lastXp.put(p.getUniqueId(),now);}save();}
 private void applyPassives(){for(Player p:Bukkit.getOnlinePlayers()){Job j=job(p);if(j==null)continue;int lv=level(p,j.name());if(lv<=0)continue;
  if(j==Job.MADENCI && lv>=3)p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,60,0,true,false));
  if(j==Job.POLIS && lv>=5)p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,60,0,true,false));
  if(j==Job.MAFYA && lv>=5)p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH,60,0,true,false));
  if(j==Job.DOKTOR && lv>=3)p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,60,0,true,false));
 }}
 private ItemStack item(Material m,String name,String... lore){ItemStack it=new ItemStack(m);ItemMeta im=it.getItemMeta();im.setDisplayName(name);im.setLore(Arrays.asList(lore));it.setItemMeta(im);return it;}
 private void open(Player p){Job j=job(p);if(j==null){p.sendMessage("§cÖnce bir meslek seçmelisin.");return;}Inventory inv=Bukkit.createInventory(null,45,TITLE);inv.setItem(4,item(Material.NETHER_STAR,"§6§lYETENEK PUANLARI","§eSK: §f"+points(p),"§7Meslek: "+j.display,"§8Her 25 meslek XP = 1 SK"));
  String[] names={"HIZLI ÜRETİM","USTALIK","DAYANIKLILIK","UZMANLIK","EFSANE YETENEK"};Material[] mats={Material.IRON_PICKAXE,Material.DIAMOND,Material.SHIELD,Material.EMERALD,Material.NETHER_STAR};
  for(int i=0;i<5;i++){int lv=level(p,j.name()+"_"+i);int cost=(i+1)*2;inv.setItem(10+i*2,item(mats[i],"§e§l"+names[i],"§7Seviye: §f"+lv+"/5","§7Geliştirme bedeli: §6"+cost+" SK","§aSatın almak için tıkla","§8Yalnızca "+j.display+" mesleğinde"));}
  inv.setItem(40,item(Material.ARROW,"§cGeri","§7Meslek menüsüne dönmek için /meslek"));p.openInventory(inv);}
 @EventHandler public void onOpen(InventoryOpenEvent e){if(e.getPlayer() instanceof Player && e.getView().getTitle().contains("MESLEK SEÇ")){e.getInventory().setItem(31,item(Material.NETHER_STAR,"§6§lYETENEKLER (SK)","§7Mesleğine özel yetenekleri geliştir.","§eAçmak için tıkla"));}}
 @EventHandler public void click(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;String title=e.getView().getTitle();if(title.contains("MESLEK SEÇ")){if(e.getRawSlot()==31){e.setCancelled(true);open(p);}return;}if(!title.equals(TITLE))return;e.setCancelled(true);int slot=e.getRawSlot();if(slot<0||slot>=e.getInventory().getSize())return;if(slot==40){p.closeInventory();p.performCommand("meslek");return;}if(slot<10||slot>18)return;int index=(slot-10)/2;if((slot-10)%2!=0)return;Job j=job(p);if(j==null)return;String key=j.name()+"_"+index;int lv=level(p,key),cost=(index+1)*2;if(lv>=5){p.sendMessage("§cBu yetenek maksimum seviyede!");return;}if(points(p)<cost){p.sendMessage("§cYeterli SK puanin yok!");return;}setPoints(p,points(p)-cost);data.set(base(p)+".skills."+key,lv+1);save();p.sendMessage("§aYetenek geliştirildi: §e"+(lv+1)+"/5");open(p);}
 @Override public boolean onCommand(CommandSender s,Command c,String label,String[] a){if(c.getName().equalsIgnoreCase("sk")){if(!(s instanceof Player p))return true;open(p);return true;}if(!s.hasPermission("rp.admin")){s.sendMessage("§cYetkin yok.");return true;}if(a.length!=2){s.sendMessage("§c/skver <oyuncu> <miktar>");return true;}Player target=Bukkit.getPlayerExact(a[0]);if(target==null){s.sendMessage("§cOyuncu çevrimiçi değil.");return true;}try{int n=Integer.parseInt(a[1]);if(n<=0||n>100000)throw new NumberFormatException();addPoints(target,n);s.sendMessage("§a"+target.getName()+" oyuncusuna "+n+" SK verildi.");target.sendMessage("§6[SK] §eYönetici sana "+n+" SK verdi.");}catch(NumberFormatException ex){s.sendMessage("§cGeçerli bir pozitif miktar yaz.");}return true;}
}
